#pragma once
#include "object.h"
#include <string>
class player :
	public object
{
public :
	
	
};

