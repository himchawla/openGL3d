Game is lacking text rendering but most features are present.
Press [Enter] to Begin.
Press [B] to attack.
Press [W],[A],[S] and [D] to move.
Game over screen is signifid by maroon colour while game victory is by Green.
Once complete press Enter again to just right back.
The game has 3 levels.

For the mechanics of Animations, input and enemies vectors are used.

This game is built using openGL and C++. 